import './App.css';
import Search from './components/Search/Search';

function App() {
  return (
    <div className="App">
     <Search/>
    </div>
  );
}

export default App;
